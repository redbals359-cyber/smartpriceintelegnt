# Smart Price Intelligence

Dashboard hijau untuk memantau harga bawang merah. Wilayah dapat dipilih berdasarkan provinsi dan kabupaten/kota. Jenis harga dipisahkan menjadi produsen, grosir, dan eceran.

## Status penting

Proyek ini **belum terhubung ke harga pasar aktual**. Saat konfigurasi API belum diisi, backend menampilkan data simulasi dan memberi label MODE DEMO. Jangan menggunakan angka demo untuk keputusan jual-beli.

Badan Pangan Nasional menyediakan WebAPI NFA. Pendaftaran dan verifikasi diperlukan sebelum API key diberikan. Dokumentasi menyebut API key dikirim melalui header `X-Authorization`:
https://webapi.badanpangan.go.id/documentation

Panel Harga Pangan Bapanas menjelaskan bahwa data panel diperbarui harian, bukan setiap detik:
https://dev-panelharga.badanpangan.go.id/faq

## Isi proyek

- `index.html`, `style.css`, `script.js`: tampilan dashboard.
- `api/harga.js`: backend Vercel.
- `lib/data-source.js`: normalisasi respons API.
- `lib/price-engine.js`: perbandingan perubahan harga.
- `vercel.json`: konfigurasi Vercel.

## Menjalankan lokal

1. Instal Node.js versi 20 atau lebih baru.
2. Instal Vercel CLI: `npm i -g vercel`
3. Di folder proyek jalankan: `vercel dev`
4. Buka alamat lokal yang ditampilkan Vercel.

Tanpa API key, website tetap berjalan dalam MODE DEMO.

## Deploy ke GitHub dan Vercel

1. Buat repository GitHub.
2. Unggah semua file dan folder proyek ini.
3. Login ke Vercel menggunakan GitHub.
4. Import repository.
5. Deploy.

## Mengaktifkan API resmi

1. Pelajari dokumentasi dan daftar WebAPI NFA melalui kanal resmi Bapanas.
2. Tunggu verifikasi akun dan API key dari pengelola.
3. Pastikan endpoint yang diberikan memang menyediakan data bawang merah, tingkat harga, wilayah, tanggal, dan satuan yang dibutuhkan.
4. Di Vercel buka Project Settings > Environment Variables.
5. Tambahkan:
   - `BAPANAS_API_URL` = URL endpoint resmi yang diberikan.
   - `BAPANAS_API_KEY` = API key rahasia.
6. Redeploy.
7. Cocokkan struktur JSON dari endpoint dengan `lib/data-source.js`.

**Jangan menebak endpoint API.** Halaman dokumentasi umum tidak mencantumkan endpoint harga tertentu pada bagian yang berhasil diverifikasi. Endpoint dan struktur respons harus diperoleh dari dokumentasi akun/API yang disetujui.

## Catatan data dan cakupan

- Pilihan provinsi dan kabupaten/kota memakai layanan referensi wilayah pihak ketiga dari emsifa. Jika layanan gagal, daftar provinsi cadangan tersedia; daftar kabupaten/kota memerlukan koneksi.
- Saat ini filter wilayah hanya membentuk pilihan UI. Backend contoh belum menerapkan filter pada API resmi karena parameter endpoint harus mengikuti dokumentasi yang sebenarnya.
- Jenis harga ditampilkan terpisah. Jangan mencampur produsen, grosir, dan eceran dalam satu rata-rata.
- Perbandingan harga harus menggunakan tanggal, wilayah, jenis pasar, kualitas, varietas, dan satuan yang sebanding.
- Cache backend contoh adalah 5 menit. Ini bukan jaminan bahwa sumber data memperbarui harga setiap 5 menit.
- Grafik saat ini menampilkan titik data yang dikirim API. Penyimpanan riwayat permanen dengan Supabase adalah tahap integrasi berikutnya; data tidak otomatis menjadi arsip hanya karena dashboard menampilkan grafik.

## Tahap pengembangan berikutnya

1. Integrasi endpoint resmi dan filter sesuai parameter API.
2. Simpan snapshot harga ke Supabase.
3. Tambahkan perbandingan beberapa kabupaten/kota.
4. Tambahkan penawaran langsung dari industri/pembeli sebagai sumber terpisah.
5. Bangun rekomendasi harga indikatif setelah cukup data transaksi tersedia.
