// Vercel Serverless Function. API key hanya disimpan di Environment Variables Vercel.
const { normalizeProviderResponse } = require("../lib/data-source");

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "s-maxage=300, stale-while-revalidate=60");
  const { commodity="Bawang Merah", priceType="produsen", province="", city="" } = req.query || {};

  // Endpoint resmi tidak ditebak. Isi BAPANAS_API_URL setelah memperoleh dokumentasi akses dan persetujuan API.
  const apiUrl = process.env.BAPANAS_API_URL;
  const apiKey = process.env.BAPANAS_API_KEY;

  if (!apiUrl || !apiKey) {
    return res.status(200).json({
      mode:"demo",
      source:"Data simulasi (bukan harga pasar)",
      fetchedAt:new Date().toISOString(),
      data:[
        {commodity, region:city || province || "Nganjuk (simulasi)", price_type:priceType, price:25000, date:"2026-11-02", source:"SIMULASI"},
        {commodity, region:city || province || "Nganjuk (simulasi)", price_type:priceType, price:24500, date:"2026-11-01", source:"SIMULASI"},
        {commodity, region:city || province || "Nganjuk (simulasi)", price_type:priceType, price:24800, date:"2026-10-31", source:"SIMULASI"}
      ]
    });
  }

  try {
    const url = new URL(apiUrl);
    // Parameter filter hanya dikirim jika endpoint resmi yang diberikan memang mendukungnya.
    const upstream = await fetch(url.toString(), {
      headers: { "X-Authorization": apiKey, "Accept":"application/json" }
    });
    if (!upstream.ok) throw new Error(`Sumber data merespons HTTP ${upstream.status}`);
    const raw = await upstream.json();
    const data = normalizeProviderResponse(raw, {commodity, priceType, province, city});
    if (!data.length) throw new Error("Respons sumber diterima, tetapi format datanya belum dikenali. Sesuaikan lib/data-source.js dengan dokumentasi endpoint.");
    return res.status(200).json({
      mode:"live", source:"Badan Pangan Nasional (API)", fetchedAt:new Date().toISOString(), data
    });
  } catch (error) {
    return res.status(502).json({error:`Gagal mengambil data sumber: ${error.message}`});
  }
};
