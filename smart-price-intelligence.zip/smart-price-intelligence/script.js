const $ = (id) => document.getElementById(id);
let chart;
let currentRows = [];

const provinceFallback = [
  ["11","Aceh"],["12","Sumatera Utara"],["13","Sumatera Barat"],["14","Riau"],
  ["15","Jambi"],["16","Sumatera Selatan"],["17","Bengkulu"],["18","Lampung"],
  ["19","Kepulauan Bangka Belitung"],["21","Kepulauan Riau"],["31","DKI Jakarta"],
  ["32","Jawa Barat"],["33","Jawa Tengah"],["34","DI Yogyakarta"],["35","Jawa Timur"],
  ["36","Banten"],["51","Bali"],["52","Nusa Tenggara Barat"],["53","Nusa Tenggara Timur"],
  ["61","Kalimantan Barat"],["62","Kalimantan Tengah"],["63","Kalimantan Selatan"],
  ["64","Kalimantan Timur"],["65","Kalimantan Utara"],["71","Sulawesi Utara"],
  ["72","Sulawesi Tengah"],["73","Sulawesi Selatan"],["74","Sulawesi Tenggara"],
  ["75","Gorontalo"],["76","Sulawesi Barat"],["81","Maluku"],["82","Maluku Utara"],
  ["91","Papua Barat"],["94","Papua"]
];

function rupiah(value) {
  return new Intl.NumberFormat("id-ID", {style:"currency", currency:"IDR", maximumFractionDigits:0}).format(value);
}
function setNotice(message, type="") {
  $("notice").textContent = message;
  $("notice").className = `notice ${type}`;
}
async function loadProvinces() {
  const select = $("province");
  try {
    const res = await fetch("https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json");
    if (!res.ok) throw new Error("Wilayah API tidak tersedia");
    const data = await res.json();
    select.innerHTML = '<option value="">Pilih provinsi</option>' + data.map(p => `<option value="${p.id}">${p.name}</option>`).join("");
  } catch {
    select.innerHTML = '<option value="">Pilih provinsi</option>' + provinceFallback.map(p => `<option value="${p[0]}">${p[1]}</option>`).join("");
    setNotice("Daftar provinsi memakai data cadangan. Pilihan kabupaten/kota akan dicoba dimuat saat provinsi dipilih.", "demo");
  }
}
async function loadCities(provinceId) {
  const city = $("city");
  city.disabled = true;
  city.innerHTML = '<option value="">Memuat kabupaten/kota...</option>';
  if (!provinceId) {
    city.innerHTML = '<option value="">Semua kabupaten/kota</option>';
    return;
  }
  try {
    const res = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/regencies/${provinceId}.json`);
    if (!res.ok) throw new Error("Gagal memuat kabupaten/kota");
    const data = await res.json();
    city.innerHTML = '<option value="">Semua kabupaten/kota</option>' + data.map(c => `<option value="${c.id}">${c.name}</option>`).join("");
    city.disabled = false;
  } catch {
    city.innerHTML = '<option value="">Daftar wilayah tidak tersedia</option>';
    setNotice("Daftar kabupaten/kota gagal dimuat. Coba lagi nanti.", "error");
  }
}
function render(rows, meta={}) {
  currentRows = rows || [];
  const selectedCity = $("city").selectedOptions[0]?.textContent;
  const selectedProvince = $("province").selectedOptions[0]?.textContent;
  const location = selectedCity && selectedCity !== "Semua kabupaten/kota" ? selectedCity : (selectedProvince || "Indonesia");
  $("locationLabel").textContent = location;
  $("priceLevel").textContent = `Tingkat ${$("priceType").value}`;
  $("recordCount").textContent = `${currentRows.length} data`;
  if (!currentRows.length) {
    $("latestPrice").textContent = "—"; $("priceChange").textContent = "—";
    $("updatedAt").textContent = "—"; $("sourceLabel").textContent = "Belum ada sumber";
    $("priceRows").innerHTML = '<tr><td colspan="5" class="empty">Tidak ada data untuk pilihan ini.</td></tr>';
    $("insightText").textContent = "Belum ada data harga yang cocok. Periksa sumber data atau ubah filter wilayah.";
    drawChart([], []);
    return;
  }
  const sorted = [...currentRows].sort((a,b) => new Date(b.date || 0) - new Date(a.date || 0));
  const latest = sorted[0];
  const previous = sorted[1];
  $("latestPrice").textContent = rupiah(latest.price);
  $("updatedAt").textContent = latest.date || "Tanggal tidak tersedia";
  $("sourceLabel").textContent = latest.source || "Sumber tidak diketahui";
  if (previous) {
    const diff = latest.price - previous.price;
    $("priceChange").textContent = `${diff > 0 ? "+" : ""}${rupiah(diff)}`;
    $("changeCaption").textContent = diff > 0 ? "Naik dari data sebelumnya" : diff < 0 ? "Turun dari data sebelumnya" : "Tidak berubah";
  } else {
    $("priceChange").textContent = "—"; $("changeCaption").textContent = "Belum ada data pembanding";
  }
  $("insightText").textContent = previous
    ? `Harga terbaru tercatat ${rupiah(latest.price)} per kg. Dibandingkan titik data sebelumnya, harga ${latest.price > previous.price ? "naik" : latest.price < previous.price ? "turun" : "tidak berubah"} ${rupiah(Math.abs(latest.price-previous.price))}. Perbandingan ini hanya sah jika jenis harga, wilayah, dan spesifikasi komoditasnya sama.`
    : `Harga terbaru tercatat ${rupiah(latest.price)} per kg. Belum tersedia titik data sebelumnya untuk menghitung perubahan.`;
  $("priceRows").innerHTML = sorted.map(r => `<tr><td>${escapeHtml(r.region || location)}</td><td>${escapeHtml(r.price_type || $("priceType").value)}</td><td><b>${rupiah(r.price)}</b></td><td>${escapeHtml(r.date || "—")}</td><td>${escapeHtml(r.source || "—")}</td></tr>`).join("");
  drawChart(sorted.slice().reverse().map(r=>r.date), sorted.slice().reverse().map(r=>r.price));
}
function drawChart(labels, values) {
  const ctx = $("priceChart").getContext("2d");
  if (chart) chart.destroy();
  chart = new Chart(ctx, {
    type:"line",
    data:{labels, datasets:[{label:"Harga (Rp/kg)",data:values,borderColor:"#15803d",backgroundColor:"rgba(21,128,61,.10)",fill:true,tension:.3,pointRadius:3}]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{ticks:{callback:v=>"Rp"+new Intl.NumberFormat("id-ID").format(v)}}}}
  });
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
async function fetchPrices() {
  const button = $("refreshBtn"); button.disabled = true; button.textContent = "Memuat...";
  setNotice("Menghubungi backend dan sumber data...");
  const params = new URLSearchParams({
    commodity:$("commodity").value,
    priceType:$("priceType").value,
    province:$("province").selectedOptions[0]?.textContent || "",
    city:$("city").selectedOptions[0]?.textContent || ""
  });
  try {
    const res = await fetch(`/api/harga?${params.toString()}`);
    const payload = await res.json();
    if (!res.ok) throw new Error(payload.error || "Gagal mengambil data.");
    render(payload.data || [], payload);
    if (payload.mode === "demo") {
      setNotice("MODE DEMO: tampilan memakai data simulasi. Belum terhubung ke harga pasar aktual. Ikuti README untuk mengaktifkan API resmi.", "demo");
    } else {
      setNotice(`Data berhasil dimuat dari ${payload.source || "sumber data"}. Waktu pengambilan: ${payload.fetchedAt || "tidak diketahui"}.`);
    }
  } catch (err) {
    render([]);
    setNotice(`${err.message} Pastikan konfigurasi API sudah benar.`, "error");
  } finally {
    button.disabled = false; button.textContent = "Perbarui data";
  }
}
$("province").addEventListener("change", async e => { await loadCities(e.target.value); });
$("refreshBtn").addEventListener("click", fetchPrices);
$("priceType").addEventListener("change", fetchPrices);
(async function init(){ await loadProvinces(); await fetchPrices(); })();
